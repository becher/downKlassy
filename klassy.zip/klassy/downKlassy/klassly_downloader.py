"""Outil local pour telecharger les photos et videos des espaces Klassly.

Lancer : python klassly_downloader.py  (puis la page s'ouvre dans le navigateur)
"""
import datetime
import http.cookiejar
import json
import mimetypes
import os
import re
import shutil
import subprocess
import threading
import time
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit
import urllib.request

API_URL = "https://api2.klassroom.co"
SITE_URL = "https://fr.klass.ly"
APP_ID = "553e7f3c01ae1"
APP_VERSION = "5.0"
HOST = "127.0.0.1"
PORT = 8765
DEFAULT_DIR = os.path.join(os.path.expanduser("~"), "Downloads", "Klassly")
MEDIA_TYPES = {"image", "video"}


class KlasslyError(Exception):
    pass


def build_opener():
    # KLASSLY_PROXY (ex: http://proxy.entreprise:8080) force un proxy ; sinon HTTP(S)_PROXY est utilise.
    proxy = os.environ.get("KLASSLY_PROXY")
    handlers = [urllib.request.ProxyHandler({"http": proxy, "https": proxy})] if proxy else []
    # Le cookie jar garde le JSESSIONID du login, requis pour telecharger les medias.
    handlers.append(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    return urllib.request.build_opener(*handlers)


OPENER = build_opener()


def encode_multipart(fields):
    boundary = uuid.uuid4().hex
    parts = []
    for key, value in fields.items():
        parts.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode("utf-8")
        )
    parts.append(f"--{boundary}--\r\n".encode("utf-8"))
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


class KlasslyAPI:
    def __init__(self):
        self.device = "web-" + uuid.uuid4().hex[:13]
        self.token = None
        self.user_name = None

    def call(self, method, params=None):
        fields = {
            "device": self.device,
            "app_id": APP_ID,
            "version": APP_VERSION,
            "culture": "fr",
            "apptype": "klassroom",
            "gmt_offset": str(int(-time.timezone / 60)),
        }
        if self.token:
            fields["auth_token"] = self.token
        for key, value in (params or {}).items():
            if value is not None:
                fields[key] = value
        body, ctype = encode_multipart(fields)
        req = urllib.request.Request(f"{API_URL}/{method}", data=body, headers={"Content-Type": ctype})
        for attempt in range(1, 4):
            try:
                with OPENER.open(req, timeout=60) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                break
            except HTTPError as err:
                try:
                    data = json.loads(err.read().decode("utf-8"))
                    break
                except ValueError:
                    raise KlasslyError(f"Erreur HTTP {err.code} sur {method}")
            except (URLError, ConnectionError, TimeoutError) as err:
                # Coupures ponctuelles du serveur : on re-essaie avant d'abandonner.
                if attempt == 3:
                    raise KlasslyError(
                        f"Impossible de joindre Klassly ({getattr(err, 'reason', err)}). Verifiez la connexion internet "
                        "ou le proxy (variable KLASSLY_PROXY)."
                    )
                time.sleep(2 * attempt)
        if not data.get("ok"):
            raise KlasslyError(data.get("message") or data.get("error") or f"Erreur sur {method}")
        return data

    def login(self, phone, password):
        data = self.call("auth.basic", {"phone": phone, "password": password})
        self.token = data.get("auth_token")
        user = data.get("user") or {}
        self.user_name = " ".join(filter(None, [user.get("firstname"), user.get("lastname")])) or phone
        return self.user_name

    def list_spaces(self):
        data = self.call("klass.list")
        klasses = data.get("klasses") or {}
        items = list(klasses.values()) if isinstance(klasses, dict) else list(klasses)
        spaces = []
        for k in items:
            spaces.append({
                "id": str(k.get("id")),
                "name": k.get("name") or k.get("title") or f"Espace {k.get('id')}",
            })
        return sorted(spaces, key=lambda s: s["name"].lower())


def parse_timestamp(value):
    """Retourne un timestamp en secondes, ou None si la date n'est pas lisible."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value) / 1000 if value > 1e11 else float(value)
    try:
        return datetime.datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def as_list(obj):
    if isinstance(obj, dict):
        return list(obj.values())
    return list(obj or [])


def iter_posts(api, klass_id, log):
    cursor_ms = int(time.time() * 1000)
    seen = set()
    while True:
        data = api.call("klass.history", {
            "id": klass_id, "type": "post", "filter": "all", "from": cursor_ms,
        })
        posts = as_list(data.get("posts"))
        if not posts:
            break
        new = 0
        for post in posts:
            if post.get("id") not in seen:
                seen.add(post.get("id"))
                new += 1
                yield post
        stamps = [s for s in (parse_timestamp(p.get("date")) for p in posts) if s is not None]
        if not stamps or new == 0 or len(posts) < 10:
            break
        cursor_ms = int(min(stamps) * 1000) - 1
    log(f"  {len(seen)} publications parcourues")


def iter_album_attachments(api, klass_id, log):
    data = api.call("klass.load_albums", {"klassID": klass_id})
    albums = as_list(data.get("albums"))
    for album in albums:
        try:
            detail = api.call("klass.load_album", {"klassID": klass_id, "albumID": album.get("id")})
        except KlasslyError as err:
            log(f"  Album ignore ({album.get('name', album.get('id'))}) : {err}")
            continue
        for att in as_list((detail.get("album") or {}).get("attachments")):
            yield att
    log(f"  {len(albums)} albums parcourus")


def is_media(att):
    if att.get("type") in MEDIA_TYPES:
        return True
    mime = att.get("mimetype") or ""
    return mime.startswith("image/") or mime.startswith("video/")


def safe_name(name):
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(name)).strip(" .") or "fichier"


def build_filename(att):
    url = att.get("url") or ""
    name = att.get("name") or os.path.basename(url.split("?")[0]) or f"media_{att.get('id')}"
    base, ext = os.path.splitext(safe_name(name))
    if not ext:
        ext = mimetypes.guess_extension(att.get("mimetype") or "") or (".mp4" if att.get("type") == "video" else ".jpg")
    return f"{att.get('id')}_{base}{ext}"


def media_url(url):
    # Meme reecriture que le site : data.klassroom.co/<chemin> -> www.klass.ly/_data/<chemin>
    for host_path in ("data.klassroom.co/", "www.klassroom.co/_data/", "www.klassroom.fr/_data/"):
        if host_path in url:
            url = url.replace(host_path, "www.klass.ly/_data/", 1)
            break
    if not url.startswith("http"):
        url = "https://" + url.lstrip("/")
    return url


def download_file(url, path, cookie_header, attempts=3):
    full_url = urljoin(SITE_URL + "/", media_url(url))
    headers = {"User-Agent": "Mozilla/5.0", "Referer": SITE_URL + "/", "Accept": "*/*", "Cookie": cookie_header}
    tmp = path + ".part"
    for attempt in range(1, attempts + 1):
        try:
            req = urllib.request.Request(full_url, headers=headers)
            with OPENER.open(req, timeout=180) as resp, open(tmp, "wb") as out:
                shutil.copyfileobj(resp, out, 1024 * 256)
            os.replace(tmp, path)
            return
        except HTTPError as err:
            # Un 403 ne se corrige pas en re-essayant : on remonte l'hote/chemin pour diagnostic.
            target = urlsplit(full_url)
            raise KlasslyError(f"{err} [hote={target.netloc} chemin={target.path[:80]}]")
        except (URLError, ConnectionError, TimeoutError) as err:
            if attempt == attempts:
                raise
            time.sleep(2 * attempt)



class Job:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.finished = False
        self.logs = []
        self.downloaded = 0
        self.skipped = 0
        self.errors = 0

    def log(self, message):
        with self.lock:
            self.logs.append(f"{time.strftime('%H:%M:%S')}  {message}")
            self.logs = self.logs[-500:]

    def snapshot(self):
        with self.lock:
            return {
                "running": self.running,
                "finished": self.finished,
                "downloaded": self.downloaded,
                "skipped": self.skipped,
                "errors": self.errors,
                "logs": list(self.logs),
            }


API = KlasslyAPI()
JOB = Job()


def run_download(klass_ids, names, dest_root, media_auth):
    # Cookies attendus par www.klass.ly pour les medias : klassroomauth (copie du navigateur) + token du login.
    cookie_header = f"klassroomauth={media_auth}; klassroom_token={API.token}; klassroom_device={API.device}"
    JOB.running, JOB.finished = True, False
    JOB.downloaded = JOB.skipped = JOB.errors = 0
    JOB.logs = []
    try:
        for klass_id in klass_ids:
            space = names.get(klass_id, f"Espace {klass_id}")
            folder = os.path.join(dest_root, safe_name(space))
            os.makedirs(folder, exist_ok=True)
            JOB.log(f"Espace : {space} -> {folder}")
            try:
                attachments = {}
                for post in iter_posts(API, klass_id, JOB.log):
                    for att in as_list(post.get("attachments")):
                        attachments.setdefault(att.get("id"), att)
                for att in iter_album_attachments(API, klass_id, JOB.log):
                    attachments.setdefault(att.get("id"), att)
                media = [a for a in attachments.values() if is_media(a) and a.get("url")]
                JOB.log(f"  {len(media)} photo(s)/video(s) trouvee(s)")
                for att in media:
                    filename = build_filename(att)
                    path = os.path.join(folder, filename)
                    if os.path.exists(path):
                        JOB.skipped += 1
                        continue
                    try:
                        download_file(att["url"], path, cookie_header)
                        JOB.downloaded += 1
                    except Exception as err:
                        JOB.errors += 1
                        JOB.log(f"  Erreur {filename} : {err}")
            except Exception as err:
                JOB.errors += 1
                JOB.log(f"Erreur espace {space} : {err}")
        JOB.log(f"Termine : {JOB.downloaded} telecharge(s), {JOB.skipped} deja present(s), {JOB.errors} erreur(s)")
    finally:
        JOB.running, JOB.finished = False, True


def pick_folder(initial):
    script = (
        "Add-Type -AssemblyName System.Windows.Forms; "
        "$d = New-Object System.Windows.Forms.FolderBrowserDialog; "
        "$d.Description = 'Choisir le dossier de sauvegarde Klassly'; "
        f"$d.SelectedPath = '{initial.replace(chr(39), chr(39) * 2)}'; "
        "$d.ShowNewFolderButton = $true; "
        "if ($d.ShowDialog() -eq 'OK') { Write-Output $d.SelectedPath }"
    )
    result = subprocess.run(
        ["powershell", "-NoProfile", "-STA", "-Command", script],
        capture_output=True, text=True, timeout=600,
    )
    return result.stdout.strip()


PAGE = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Klassly - Telechargement</title>
<style>
body { font-family: Segoe UI, Arial, sans-serif; background: #f4f6fb; margin: 0; color: #222; }
header { background: #2d6cdf; color: #fff; padding: 16px 24px; font-size: 20px; font-weight: 600; }
main { max-width: 820px; margin: 24px auto; padding: 0 16px; }
.card { background: #fff; border-radius: 10px; padding: 20px; margin-bottom: 18px; box-shadow: 0 1px 4px rgba(0,0,0,.08); }
h2 { margin: 0 0 12px; font-size: 17px; }
input[type=text], input[type=password], input[type=tel] { width: 100%; padding: 9px; border: 1px solid #ccd; border-radius: 6px; box-sizing: border-box; font-size: 14px; }
button { background: #2d6cdf; color: #fff; border: 0; border-radius: 6px; padding: 9px 16px; font-size: 14px; cursor: pointer; }
button:disabled { background: #9ab; cursor: default; }
button.secondary { background: #e6ebf5; color: #234; }
.row { display: flex; gap: 10px; align-items: center; margin-top: 10px; }
.spaces label { display: flex; align-items: center; gap: 10px; padding: 8px 6px; border-bottom: 1px solid #eef; cursor: pointer; }
#log { background: #101418; color: #d6f5d6; font-family: Consolas, monospace; font-size: 13px; height: 260px; overflow-y: auto; padding: 10px; border-radius: 6px; white-space: pre-wrap; }
.stats { margin-top: 8px; font-size: 14px; color: #456; }
.error { color: #b00020; font-size: 14px; margin-top: 8px; }
.hidden { display: none; }
</style>
</head>
<body>
<header>Klassly - Telechargement des photos et videos</header>
<main>
  <div class="card" id="loginCard">
    <h2>1. Connexion Klassly</h2>
    <input type="tel" id="phone" placeholder="Numero de telephone (identifiant Klassly)" value="+33">
    <div style="height:8px"></div>
    <input type="password" id="password" placeholder="Mot de passe">
    <div class="row"><button id="loginBtn">Se connecter</button><span id="userInfo" class="stats"></span></div>
    <div class="error" id="loginError"></div>
  </div>

  <div class="card hidden" id="spacesCard">
    <h2>2. Choisir les espaces</h2>
    <div class="row" style="margin-top:0"><button class="secondary" id="selectAll">Tout selectionner</button><button class="secondary" id="selectNone">Tout deselectionner</button></div>
    <div class="spaces" id="spaces" style="margin-top:10px"></div>
  </div>

  <div class="card hidden" id="folderCard">
    <h2>3. Dossier d'enregistrement</h2>
    <input type="text" id="folder">
    <div class="row"><button class="secondary" id="pickBtn">Choisir le dossier...</button></div>
    <div style="height:10px"></div>
    <label>Cookie klassroomauth (www.klass.ly), copie depuis le navigateur :</label>
    <input type="password" id="mediaAuth" placeholder="Valeur du cookie klassroomauth">
  </div>

  <div class="card hidden" id="runCard">
    <h2>4. Telechargement</h2>
    <div class="row" style="margin-top:0"><button id="startBtn">Lancer le telechargement</button></div>
    <div class="stats" id="stats"></div>
    <div class="error" id="runError"></div>
    <div style="height:10px"></div>
    <div id="log"></div>
  </div>
</main>
<script>
const $ = (id) => document.getElementById(id);
let pollTimer = null;

async function api(path, body) {
  const res = await fetch(path, {
    method: body === undefined ? 'GET' : 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await res.json();
  if (!data.ok) throw new Error(data.error || 'Erreur');
  return data;
}

function show(id) { $(id).classList.remove('hidden'); }

$('loginBtn').onclick = async () => {
  $('loginError').textContent = '';
  $('loginBtn').disabled = true;
  try {
    const d = await api('/api/login', { phone: $('phone').value.trim(), password: $('password').value });
    $('password').value = '';
    $('userInfo').textContent = 'Connecte : ' + d.user;
    await loadSpaces();
  } catch (e) {
    $('loginError').textContent = e.message;
  } finally {
    $('loginBtn').disabled = false;
  }
};

async function loadSpaces() {
  const d = await api('/api/spaces');
  const box = $('spaces');
  box.innerHTML = '';
  d.spaces.forEach((s) => {
    const label = document.createElement('label');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.value = s.id;
    cb.dataset.name = s.name;
    label.appendChild(cb);
    label.appendChild(document.createTextNode(s.name));
    box.appendChild(label);
  });
  if (!d.spaces.length) box.textContent = 'Aucun espace trouve.';
  show('spacesCard');
  show('folderCard');
  show('runCard');
  if (!$('folder').value) $('folder').value = d.defaultDir;
}

$('selectAll').onclick = () => document.querySelectorAll('#spaces input').forEach((c) => c.checked = true);
$('selectNone').onclick = () => document.querySelectorAll('#spaces input').forEach((c) => c.checked = false);

$('pickBtn').onclick = async () => {
  try {
    const d = await api('/api/pick-folder', { initial: $('folder').value });
    if (d.path) $('folder').value = d.path;
  } catch (e) {
    $('runError').textContent = e.message;
  }
};

$('startBtn').onclick = async () => {
  $('runError').textContent = '';
  const selected = [...document.querySelectorAll('#spaces input:checked')];
  if (!selected.length) { $('runError').textContent = 'Selectionnez au moins un espace.'; return; }
  if (!$('folder').value.trim()) { $('runError').textContent = 'Choisissez un dossier.'; return; }
  try {
    await api('/api/download', {
      spaces: selected.map((c) => ({ id: c.value, name: c.dataset.name })),
      folder: $('folder').value.trim(),
      media_auth: $('mediaAuth').value.trim(),
    });
    $('startBtn').disabled = true;
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(poll, 1500);
    poll();
  } catch (e) {
    $('runError').textContent = e.message;
  }
};

async function poll() {
  const s = await (await fetch('/api/status')).json();
  $('log').textContent = s.logs.join('\n');
  $('log').scrollTop = $('log').scrollHeight;
  $('stats').textContent = `Telecharges : ${s.downloaded}  |  Deja presents : ${s.skipped}  |  Erreurs : ${s.errors}`;
  if (s.finished) {
    clearInterval(pollTimer);
    $('startBtn').disabled = false;
  }
}
</script>
</body>
</html>
"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code, payload, content_type="application/json; charset=utf-8"):
        body = payload if isinstance(payload, bytes) else json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self):
        if self.path == "/":
            self._send(200, PAGE.encode("utf-8"), "text/html; charset=utf-8")
        elif self.path == "/api/status":
            self._send(200, {"ok": True, **JOB.snapshot()})
        elif self.path == "/api/spaces":
            try:
                self._send(200, {"ok": True, "spaces": API.list_spaces(), "defaultDir": DEFAULT_DIR})
            except KlasslyError as err:
                self._send(200, {"ok": False, "error": str(err)})
        else:
            self._send(404, {"ok": False, "error": "Introuvable"})

    def do_POST(self):
        try:
            body = self._read_json()
            if self.path == "/api/login":
                name = API.login(body.get("phone", ""), body.get("password", ""))
                self._send(200, {"ok": True, "user": name})
            elif self.path == "/api/pick-folder":
                path = pick_folder(body.get("initial") or DEFAULT_DIR)
                self._send(200, {"ok": True, "path": path})
            elif self.path == "/api/download":
                if JOB.running:
                    raise KlasslyError("Un telechargement est deja en cours.")
                spaces = body.get("spaces") or []
                folder = body.get("folder") or DEFAULT_DIR
                if not spaces:
                    raise KlasslyError("Aucun espace selectionne.")
                media_auth = (body.get("media_auth") or "").strip()
                if not media_auth:
                    raise KlasslyError("Collez la valeur du cookie klassroomauth (www.klass.ly).")
                names = {str(s["id"]): s["name"] for s in spaces}
                threading.Thread(
                    target=run_download,
                    args=([str(s["id"]) for s in spaces], names, folder, media_auth),
                    daemon=True,
                ).start()
                self._send(200, {"ok": True})
            else:
                self._send(404, {"ok": False, "error": "Introuvable"})
        except KlasslyError as err:
            self._send(200, {"ok": False, "error": str(err)})
        except Exception as err:
            self._send(500, {"ok": False, "error": f"Erreur interne : {err}"})


def main():
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    url = f"http://{HOST}:{PORT}/"
    print(f"Outil Klassly lance sur {url} (Ctrl+C pour arreter)")
    webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
